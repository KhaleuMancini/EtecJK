﻿namespace testeTamagotchi
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            reset = new Button();
            lb_nome = new Label();
            pic_animal = new PictureBox();
            lb_vida = new Label();
            lb_raca = new Label();
            btn_todolist = new Button();
            lb_dinheiro = new Label();
            label1 = new Label();
            btn_coelho = new Button();
            lb_fome = new Label();
            tFive = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)pic_animal).BeginInit();
            SuspendLayout();
            // 
            // reset
            // 
            reset.Location = new Point(241, 397);
            reset.Name = "reset";
            reset.Size = new Size(97, 32);
            reset.TabIndex = 0;
            reset.Text = "reset";
            reset.UseVisualStyleBackColor = true;
            reset.Click += reset_Click;
            // 
            // lb_nome
            // 
            lb_nome.AutoSize = true;
            lb_nome.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lb_nome.Location = new Point(264, 116);
            lb_nome.Name = "lb_nome";
            lb_nome.Size = new Size(63, 25);
            lb_nome.TabIndex = 1;
            lb_nome.Text = "label1";
            // 
            // pic_animal
            // 
            pic_animal.Location = new Point(210, 144);
            pic_animal.Name = "pic_animal";
            pic_animal.Size = new Size(171, 153);
            pic_animal.SizeMode = PictureBoxSizeMode.StretchImage;
            pic_animal.TabIndex = 2;
            pic_animal.TabStop = false;
            // 
            // lb_vida
            // 
            lb_vida.AutoSize = true;
            lb_vida.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lb_vida.Location = new Point(264, 57);
            lb_vida.Name = "lb_vida";
            lb_vida.Size = new Size(52, 21);
            lb_vida.TabIndex = 3;
            lb_vida.Text = "label1";
            // 
            // lb_raca
            // 
            lb_raca.AutoSize = true;
            lb_raca.Location = new Point(278, 300);
            lb_raca.Name = "lb_raca";
            lb_raca.Size = new Size(38, 15);
            lb_raca.TabIndex = 4;
            lb_raca.Text = "label1";
            // 
            // btn_todolist
            // 
            btn_todolist.Location = new Point(377, 397);
            btn_todolist.Name = "btn_todolist";
            btn_todolist.Size = new Size(140, 23);
            btn_todolist.TabIndex = 5;
            btn_todolist.Text = "Lista de afazeres";
            btn_todolist.UseVisualStyleBackColor = true;
            btn_todolist.Click += btn_todolist_Click;
            // 
            // lb_dinheiro
            // 
            lb_dinheiro.AutoSize = true;
            lb_dinheiro.Location = new Point(507, 62);
            lb_dinheiro.Name = "lb_dinheiro";
            lb_dinheiro.Size = new Size(13, 15);
            lb_dinheiro.TabIndex = 6;
            lb_dinheiro.Text = "0";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(403, 62);
            label1.Name = "label1";
            label1.Size = new Size(98, 15);
            label1.TabIndex = 7;
            label1.Text = "Total de dinheiro:";
            // 
            // btn_coelho
            // 
            btn_coelho.Location = new Point(447, 211);
            btn_coelho.Name = "btn_coelho";
            btn_coelho.Size = new Size(75, 23);
            btn_coelho.TabIndex = 8;
            btn_coelho.Text = "button1";
            btn_coelho.UseVisualStyleBackColor = true;
            btn_coelho.Click += btn_coelho_Click;
            // 
            // lb_fome
            // 
            lb_fome.AutoSize = true;
            lb_fome.Location = new Point(93, 63);
            lb_fome.Name = "lb_fome";
            lb_fome.Size = new Size(38, 15);
            lb_fome.TabIndex = 9;
            lb_fome.Text = "label2";
            // 
            // tFive
            // 
            tFive.Interval = 5000;
            tFive.Tick += tFive_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(624, 441);
            Controls.Add(lb_fome);
            Controls.Add(btn_coelho);
            Controls.Add(label1);
            Controls.Add(lb_dinheiro);
            Controls.Add(btn_todolist);
            Controls.Add(lb_raca);
            Controls.Add(lb_vida);
            Controls.Add(pic_animal);
            Controls.Add(lb_nome);
            Controls.Add(reset);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pic_animal).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button reset;
        public Label lb_nome;
        public Label lb_vida;
        public Label lb_raca;
        public PictureBox pic_animal;
        private Button btn_todolist;
        public Label lb_dinheiro;
        private Label label1;
        private Button btn_coelho;
        private Label lb_fome;
        private System.Windows.Forms.Timer tFive;
    }
}
