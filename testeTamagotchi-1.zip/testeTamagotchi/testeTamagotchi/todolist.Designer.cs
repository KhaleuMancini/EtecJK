﻿namespace testeTamagotchi
{
    partial class todolist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cb_quest1 = new CheckBox();
            cb_quest2 = new CheckBox();
            cb_quest3 = new CheckBox();
            lb_dinheiro = new Label();
            btn_salvar = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // cb_quest1
            // 
            cb_quest1.AutoSize = true;
            cb_quest1.Location = new Point(239, 116);
            cb_quest1.Name = "cb_quest1";
            cb_quest1.Size = new Size(109, 19);
            cb_quest1.TabIndex = 0;
            cb_quest1.Text = "testando safada";
            cb_quest1.UseVisualStyleBackColor = true;
            cb_quest1.Click += cb_quest1_Click;
            // 
            // cb_quest2
            // 
            cb_quest2.AutoSize = true;
            cb_quest2.Location = new Point(239, 141);
            cb_quest2.Name = "cb_quest2";
            cb_quest2.Size = new Size(83, 19);
            cb_quest2.TabIndex = 1;
            cb_quest2.Text = "checkBox2";
            cb_quest2.UseVisualStyleBackColor = true;
            cb_quest2.Click += cb_quest2_Click;
            // 
            // cb_quest3
            // 
            cb_quest3.AutoSize = true;
            cb_quest3.Location = new Point(239, 166);
            cb_quest3.Name = "cb_quest3";
            cb_quest3.Size = new Size(83, 19);
            cb_quest3.TabIndex = 2;
            cb_quest3.Text = "checkBox3";
            cb_quest3.UseVisualStyleBackColor = true;
            cb_quest3.Click += cb_quest3_Click;
            // 
            // lb_dinheiro
            // 
            lb_dinheiro.AutoSize = true;
            lb_dinheiro.Location = new Point(534, 49);
            lb_dinheiro.Name = "lb_dinheiro";
            lb_dinheiro.Size = new Size(13, 15);
            lb_dinheiro.TabIndex = 3;
            lb_dinheiro.Text = "0";
            // 
            // btn_salvar
            // 
            btn_salvar.Location = new Point(394, 339);
            btn_salvar.Name = "btn_salvar";
            btn_salvar.Size = new Size(75, 23);
            btn_salvar.TabIndex = 4;
            btn_salvar.Text = "button1";
            btn_salvar.UseVisualStyleBackColor = true;
            btn_salvar.Click += btn_salvar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(443, 49);
            label1.Name = "label1";
            label1.Size = new Size(85, 15);
            label1.TabIndex = 5;
            label1.Text = "Total dinheiro: ";
            // 
            // todolist
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(624, 441);
            Controls.Add(label1);
            Controls.Add(btn_salvar);
            Controls.Add(lb_dinheiro);
            Controls.Add(cb_quest3);
            Controls.Add(cb_quest2);
            Controls.Add(cb_quest1);
            Name = "todolist";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "todolist";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        public CheckBox cb_quest1;
        public CheckBox cb_quest2;
        public CheckBox cb_quest3;
        public Label lb_dinheiro;
        public Button btn_salvar;
        private Label label1;
    }
}