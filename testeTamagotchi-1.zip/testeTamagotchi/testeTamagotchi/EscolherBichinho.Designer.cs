﻿namespace testeTamagotchi
{
    partial class EscolherBichinho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pic_bichinhos = new PictureBox();
            btn_start = new Button();
            lb_nome = new Label();
            tb_nome = new TextBox();
            lb_escolhendo = new Label();
            btn_proximo = new Button();
            btn_anterior = new Button();
            ((System.ComponentModel.ISupportInitialize)pic_bichinhos).BeginInit();
            SuspendLayout();
            // 
            // pic_bichinhos
            // 
            pic_bichinhos.Location = new Point(193, 105);
            pic_bichinhos.Name = "pic_bichinhos";
            pic_bichinhos.Size = new Size(219, 157);
            pic_bichinhos.SizeMode = PictureBoxSizeMode.StretchImage;
            pic_bichinhos.TabIndex = 0;
            pic_bichinhos.TabStop = false;
            // 
            // btn_start
            // 
            btn_start.Font = new Font("Showcard Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_start.Location = new Point(193, 318);
            btn_start.Name = "btn_start";
            btn_start.Size = new Size(219, 48);
            btn_start.TabIndex = 1;
            btn_start.Text = "START";
            btn_start.UseVisualStyleBackColor = true;
            btn_start.Click += btn_start_Click;
            // 
            // lb_nome
            // 
            lb_nome.AutoSize = true;
            lb_nome.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lb_nome.Location = new Point(190, 265);
            lb_nome.Name = "lb_nome";
            lb_nome.Size = new Size(222, 21);
            lb_nome.TabIndex = 2;
            lb_nome.Text = "Digite o nome do seu bichinho";
            // 
            // tb_nome
            // 
            tb_nome.Location = new Point(193, 289);
            tb_nome.Name = "tb_nome";
            tb_nome.Size = new Size(219, 23);
            tb_nome.TabIndex = 3;
            // 
            // lb_escolhendo
            // 
            lb_escolhendo.AutoSize = true;
            lb_escolhendo.Font = new Font("Segoe UI", 17.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lb_escolhendo.Location = new Point(185, 71);
            lb_escolhendo.Name = "lb_escolhendo";
            lb_escolhendo.Size = new Size(227, 31);
            lb_escolhendo.TabIndex = 4;
            lb_escolhendo.Text = "Escolha seu bichinho";
            // 
            // btn_proximo
            // 
            btn_proximo.Location = new Point(418, 183);
            btn_proximo.Name = "btn_proximo";
            btn_proximo.Size = new Size(75, 23);
            btn_proximo.TabIndex = 5;
            btn_proximo.Text = ">";
            btn_proximo.UseVisualStyleBackColor = true;
            btn_proximo.Click += btn_proximo_Click;
            // 
            // btn_anterior
            // 
            btn_anterior.Location = new Point(112, 183);
            btn_anterior.Name = "btn_anterior";
            btn_anterior.Size = new Size(75, 23);
            btn_anterior.TabIndex = 6;
            btn_anterior.Text = "<";
            btn_anterior.UseVisualStyleBackColor = true;
            btn_anterior.Click += btn_anterior_Click;
            // 
            // EscolherBichinho
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(624, 441);
            Controls.Add(btn_anterior);
            Controls.Add(btn_proximo);
            Controls.Add(lb_escolhendo);
            Controls.Add(tb_nome);
            Controls.Add(lb_nome);
            Controls.Add(btn_start);
            Controls.Add(pic_bichinhos);
            Name = "EscolherBichinho";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "EscolherBichinho";
            ((System.ComponentModel.ISupportInitialize)pic_bichinhos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pic_bichinhos;
        private Button btn_start;
        private Label lb_nome;
        private TextBox tb_nome;
        private Label lb_escolhendo;
        private Button btn_proximo;
        private Button btn_anterior;
    }
}